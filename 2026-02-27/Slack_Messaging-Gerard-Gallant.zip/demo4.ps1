
# demo 4 - webhooks sending text and then sending blocks

# Webhook URL
$webhookUrl = ""


#----------
# 1. sending text with markup

# NOTE: 
#  - back ticks (`) need to be escapped with a second back tick (``)
#  - code blocks are automatically on their own line so no need for a \n before or after it.
#  - for a block quote to work, the '>' needs to be the first character of a new line
#
# As shown here, an image can be included in messages but they need to be publicly accessible (there are API calls you can make to upload a file to Slack: https://docs.slack.dev/messaging/working-with-files/)
$slackMessage = @"
{
  "text": "standard message via a webhook... this is *bold*, _italic_, ~strikethrough~, :smile:, ``inline code`` ``````code block`````` \n> block quote \n<https://pbs.twimg.com/profile_images/625633822235693056/lNGUneLX_400x400.jpg|link to the image> \nhttps://pbs.twimg.com/profile_images/625633822235693056/lNGUneLX_400x400.jpg" 
}
"@

# Send off the message
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 
Invoke-RestMethod -Method 'Post' -Uri $webhookUrl -ContentType 'application/json' -Body $slackMessage


<#

#----------
#  2. sending blocks

# In addition to markdown, blocks allow richer formatting. Here we show some text with an image to the right as well as
# an image appearing vertically in the text.
$slackMessage = @"
{
    "text": "fallback text",
    "blocks": [
        {
	        "type": "section",
		    "text": {
		        "type": "mrkdwn",
			    "text": "block message via a webhook... this is *bold*, _italic_, ~strikethrough~, :smile:",
		    }
	    },
        {
	        "type": "section",
		    "text": {
		        "type": "mrkdwn",
			    "text": "Some text with an image to the right:",
		    },
            "accessory": {
				"type": "image",
				"image_url": "https://pbs.twimg.com/profile_images/625633822235693056/lNGUneLX_400x400.jpg",
				"alt_text": "cat to the right"
			}
	    },
		{
			"type": "image",
			"image_url": "https://assets3.thrillist.com/v1/image/1682388/size/tl-horizontal_main.jpg",
			"alt_text": "tacos"
		},
        {
	        "type": "section",
		    "text": {
		        "type": "mrkdwn",
			    "text": "some more text... ``inline code`` \n ``````code block`````` \n> block quote",
		    }
	    }
    ]
}
"@

# Send off the message
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 
Invoke-RestMethod -Method 'Post' -Uri $webhookUrl -ContentType 'application/json' -Body $slackMessage 

#>
