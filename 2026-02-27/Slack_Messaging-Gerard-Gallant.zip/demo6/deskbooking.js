module.exports.messageToPost = {
	"blocks": [
		{
			"type": "section",
			"text": {
				"type": "mrkdwn",
				"text": "*Desk booking for [date]...*"
			}
		},
		{
			"type": "image",
			"title": {
				"type": "plain_text",
				"text": "Main Floor"
			},
			"image_url": "https://github.com/cggallant/interactive-slack-bot/blob/main/img/floor-plan.jpg?raw=true",
			"alt_text": "Main Floor"
		},
		{
			"type": "section",
			"text": {
				"type": "mrkdwn",
				"text": "Desk 1"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": "Available"
				},
				"action_id": "ReserveDesk1",
				"value": "{\"userId\":\"\"}"
			}
		},
		{
			"type": "section",
			"text": {
				"type": "mrkdwn",
				"text": "Desk 2"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": "Available"
				},
				"action_id": "ReserveDesk2",
				"value": "{\"userId\":\"\"}"
			}
		},
		{
			"type": "divider"
		},
		{
			"type": "section",
			"text": {
				"type": "mrkdwn",
				"text": "Desk 3"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": "Available"
				},
				"action_id": "ReserveDesk3",
				"value": "{\"userId\":\"\"}"
			}
		},
		{
			"type": "section",
			"text": {
				"type": "mrkdwn",
				"text": "Desk 4"
			},
			"accessory": {
				"type": "button",
				"text": {
					"type": "plain_text",
					"text": "Available"
				},
				"action_id": "ReserveDesk4",
				"value": "{\"userId\":\"\"}"
			}
		}
	]
};