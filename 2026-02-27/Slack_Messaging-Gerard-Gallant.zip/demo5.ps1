﻿# building on demo4.ps1, using chat.postMessage and chat.update instead of webhooks

$botToken = ""

# On desired channel, right click and choose 'View channel details'. The ID is at the bottom of the dialog.
# NOTE: need to @BotName in the channel to add the bot to the channel in order to send messages there.
$channelId = ""  

$newMessage = $true
$messageId = "" # Only used if $newMessage is set to $true


# NOTE: Only have the array of blocks. Don't include the '{ "text": "fallback text", "blocks": ' at the beginning or the '}' at the end.
$slackMessage = @"
    [
        {
	        "type": "section",
		    "text": {
		        "type": "mrkdwn",
			    "text": "block message via chat.postMessage and chat.update... this is *bold*, _italic_, ~strikethrough~, :smile:",
		    }
	    },
        {
	        "type": "section",
		    "text": {
		        "type": "mrkdwn",
			    "text": "Some text with an image to the right:",
		    },
            "accessory": {
				"type": "image",
				"image_url": "https://pbs.twimg.com/profile_images/625633822235693056/lNGUneLX_400x400.jpg",
				"alt_text": "cat to the right"
			}
	    },
		{
			"type": "image",
			"image_url": "https://assets3.thrillist.com/v1/image/1682388/size/tl-horizontal_main.jpg",
			"alt_text": "tacos"
		},
        {
	        "type": "section",
		    "text": {
		        "type": "mrkdwn",
			    "text": "some more text... ``inline code`` \n ``````code block`````` \n> block quote",
		    }
	    }
    ]
"@


# If we're to cerate a new message then...
if ($newMessage -eq $true){
    $Url = "https://slack.com/api/chat.postMessage"
    $body = @{
        channel = $channelId
        text = "fallback text"
        blocks = $slackMessage 
    }
}
else{ # We're editing an existing message...
    $Url = "https://slack.com/api/chat.update"
    $body = @{
        channel = $channelId
        ts = $messageId
        blocks = $slackMessage 
    }
} # End if ($newMessage -eq $true)


try{
    $headers = @{
        "Authorization" = "Bearer $botToken"
        "Content-Type" = "application/json;charset=UTF-8"
    }

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 
    $response = Invoke-RestMethod -Method "Post" -Uri $Url -Headers $headers -Body ($body | ConvertTo-Json)
    
    if ($response.ok) {
        Write-Host "Message ID (ts value): $($response.ts)"
    } else {
        Write-Error "Failed to send message. Error: $($response.error)"
    }

}catch{
    Write-Error "An error occurred during the API call: $_"
}